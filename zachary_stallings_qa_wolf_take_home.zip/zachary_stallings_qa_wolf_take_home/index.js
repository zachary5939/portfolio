const { chromium } = require("playwright");
const fs = require("fs"); // Node.js file system module

async function saveHackerNewsArticles() {
  // Launch browser
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Go to Hacker News
  await page.goto("https://news.ycombinator.com");

  // Get titles and URLs
  //".athing" is the CSS class name that acts as a individual article rows on Hacker News.
  const articles = await page.$$eval(".athing", (nodes) => {
    // Iterate nodes, only take the first 10 (per request)
    return nodes.slice(0, 10).map((node) => {
      const title = node.querySelector(".title a").innerText; //Extract title text
      const url = node.querySelector(".title a").href; //Extra article URL
      return { title, url }; //Return object containing title and url
    });
  });

  // Prepare CSV content
  const header = ["Title", "URL"];
  // Map article data into an array
  const rows = articles.map((article) => [article.title, article.url]);
  // Create CSV content as a string. Wrap fields containing commas in double quotes
  // to ensure they're correctly interpreted as a single field in spreadsheet applications.
  const csvContent = [header, ...rows]
    .map((e) =>
      e.map((value) => (value.includes(",") ? `"${value}"` : value)).join(",")
    )
    .join("\n");

  // ** Write the articles to CSV **

  // Create a new Date object
  const date = new Date();

  // Format the current date in YYYY-MM-DD format for inclusion in the filename
  const dateString = `${date.getFullYear()}-${(date.getMonth() + 1)
    .toString()
    .padStart(2, "0")}-${date.getDate().toString().padStart(2, "0")}`;

  // Create the filename by appending the formatted date string
  const fileName = `top_10_hacker_news_${dateString}.csv`;

  // Write the CSV content to a file with the generated filename
  fs.writeFileSync(fileName, csvContent);

  // Close the browser
  await browser.close();
}

(async () => {
  await saveHackerNewsArticles();
})();
